import React from 'react';
import logo from './logo.svg';
import './App.css';
import Fruitlist from './Classfruitslist'

function App() {
  
  return (
    <Fruitlist></Fruitlist>

    
  );
}

export default App;
