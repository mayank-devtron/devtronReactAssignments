import React from 'react';
import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <center className="outerclass">
    <div>
      <h1>Apply CSS styling in React application</h1>
      <h1>Welcome to TQPP</h1>
      <h1>Hello React</h1>
    </div>
    </center>
  );
}

export default App;
