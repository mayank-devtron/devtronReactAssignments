import React from 'react';
import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <center>
    <div className='colors'>
      <div className="first common"> <h1>Primary</h1></div>
      <div className="second common"><h1>Secondary</h1></div>
      <div className="third common"><h1>Success</h1></div>
      <div className="fourth common"><h1>Danger</h1></div>
      <div className="fifth common"><h1>Warning</h1></div>
    </div>
    </center>
  )
}

export default App;
